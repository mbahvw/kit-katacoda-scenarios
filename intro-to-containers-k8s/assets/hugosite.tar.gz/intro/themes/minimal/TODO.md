# TODO

- [ ] Dark theme support
- [ ] Custom background image
- [ ] Clickable tags
- [ ] Avatar picture on home page
- [ ] Port theme to Jekyll
- [ ] Custom icons in navigation bar
- [ ] Fix intro positioning on phones
- [ ] Use GitHub API to automatically retrieve projects
